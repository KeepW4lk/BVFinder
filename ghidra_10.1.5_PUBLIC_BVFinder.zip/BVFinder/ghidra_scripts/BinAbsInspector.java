//
//@author Tencent KeenLab and enhanced by n3vv
//@category Analysis
//@keybinding
//@menupath Analysis.BinAbsInspector
//@toolbar logo.gif


import com.bai.checkers.BVFinder;
import com.bai.checkers.CheckerManager;
import com.bai.env.funcs.FunctionModelManager;
import com.bai.env.funcs.externalfuncs.BasebandMemcpy;
import com.bai.solver.InterSolver;
import com.bai.util.*;
import com.bai.util.Config.HeadlessParser;
import ghidra.app.decompiler.DecompInterface;
import ghidra.app.decompiler.DecompileOptions;
import ghidra.app.plugin.assembler.Assemblers;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.block.BasicBlockModel;
import ghidra.program.model.lang.Language;
import ghidra.program.model.listing.Function;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.commons.lang3.StringUtils;

import java.awt.*;
import java.util.List;
import java.util.*;

public class BinAbsInspector extends GhidraScript {

    protected boolean prepareProgram() {
        GlobalState.jumpedFunctions = new String[4];
        GlobalState.jumpedFunctions[0] = "log";
        GlobalState.jumpedFunctions[1] = "SAECOMM_Utility__CurrentStack";
        GlobalState.jumpedFunctions[2] = "Backup";
        GlobalState.jumpedFunctions[3] = "FUN_413fe778";
        GlobalState.state = this.state;
        GlobalState.currentProgram = this.currentProgram;
        GlobalState.decompInterface = new DecompInterface();
        GlobalState.assembler = Assemblers.getAssembler(GlobalState.currentProgram);
        GlobalState.decompInterface.setOptions(new DecompileOptions());
        GlobalState.decompInterface.openProgram(GlobalState.currentProgram);
        GlobalState.flatAPI = this;
        GlobalState.icall_taints = new HashedMap();
        GlobalState.basicBlockModel = new BasicBlockModel(GlobalState.currentProgram);
        GlobalState.listing = this.currentProgram.getListing();
        Language language = GlobalState.currentProgram.getLanguage();
        return language != null;
    }

    protected boolean analyzeFromMain() {
        List<Function> functions = GlobalState.currentProgram.getListing().getGlobalFunctions("main");
        if (functions == null || functions.size() == 0) {
            return false;
        }
        Function entryFunction = functions.get(0);
        if (entryFunction == null) {
            Logging.error("Cannot find entry function");
            return false;
        }
        Logging.info("Running solver on \"" + entryFunction + "()\" function");
        InterSolver solver = new InterSolver(entryFunction, true);
        solver.run();
        return true;
    }

    protected boolean analyzeFromAddress(Address entryAddress) {
        Function entryFunction = GlobalState.flatAPI.getFunctionAt(entryAddress);
        if (entryAddress == null) {
            Logging.error("Could not find entry function at " + entryAddress);
            return false;
        }
        Logging.info("Running solver on \"" + entryFunction + "()\" function");
        println("Running solver on \"" + entryFunction + "()\" function");
        InterSolver solver = new InterSolver(entryFunction, false);
        solver.run();
        return true;
    }

    /**
     * Start analysis with following steps:
     * 1. Start from specific address if user provided, the address must be the entrypoint of a function.
     * 2. Start from "main" function if step 1 fails.
     * 3. Start from "e_entry" address from ELF header if step 2 fails.
     * @return
     */
    protected boolean analyze() {
        // ------- All APIs -------
        Function f = GlobalState.flatAPI.getFunctionAt(GlobalState.flatAPI.toAddr(0x40d46ee6));
        Set<Address> addresses = new HashSet();
        Set<Address> filtered = new HashSet();

        //** Collect Initial Taint Sources.
        BVFinder.getInitBinaryVars(f, addresses);
        println("[+] Number of Initial binary variable used address:"+addresses.size()+"");
        int initialTsources = BVFinder.tagTaintSource(addresses);
        println("[+] Number of Initial Taint Sources： "+initialTsources+"");

        //** filtered by DataRefer
        BVFinder.dataReference(addresses, filtered);
        println("[+] Number of Initial Taint Sources before filtered: " + BVFinder.tainted.size());
        println("[+] Number of Initial Taint Sources after  filtered: " + filtered.size());

        //** Collect Debug Strings.
        // BVFinder.getMsgVariabledDebugInfo(addresses,"D:\\debugString1111111111111.json");
        // use python script to filter this json file.
        // BVFinder.tGlobalvar.add(GlobalState.flatAPI.toAddr(address));

        //** Indirect Call resolving.
        GlobalState.icall = 0;
        if(GlobalState.icall == 1){
            Address fcontainsicall = GlobalState.flatAPI.toAddr(0x40d46abc);
            BVFinder.resolveIncalls(fcontainsicall);
            for(Map.Entry<Address, Address> entry: GlobalState.icall_taints.entrySet()){
                println(entry.getKey().toString() + "  " + entry.getValue() + "");
            }
            return analyzeFromAddress(fcontainsicall);
        }

        //** Static Taint Analysis.
        GlobalState.icall = 0;
        // Check memcpy-like functions.
        GlobalState.check_funcs = false;
        if(GlobalState.check_funcs){
            // mm_CopyBufferBytes
            Function memcpy = GlobalState.flatAPI.getFunctionAt(GlobalState.flatAPI.toAddr(0x40e73932));
            BasebandMemcpy.addstaticSymbols(memcpy.getName());
            addresses.clear();
            addresses.add(GlobalState.flatAPI.toAddr(0x42b162d4));
            BVFinder.tagTaintSource(addresses);
            Address fcontainsicall = GlobalState.flatAPI.toAddr(0x40779790);
            return analyzeFromAddress(fcontainsicall);
        }
        // Check loops.
        GlobalState.check_loop = true;
        if(GlobalState.check_loop){
            addresses.clear();
            addresses.add(GlobalState.flatAPI.toAddr(0x42b3d614));
            BVFinder.tagTaintSource(addresses);
            Address fcontainsicall = GlobalState.flatAPI.toAddr(0x408a8f86);
            boolean status = analyzeFromAddress(fcontainsicall);
            for(Address address: BVFinder.reported_loop_addr){
                println("Potential parsing IE via loop at" + " 0x" + address);
            }
            return status;
        }
//        Program program = GlobalState.currentProgram;
//        if (program == null) {
//            Logging.error("Import program error.");
//            return false;
//        }
//        String entryAddressStr = GlobalState.config.getEntryAddress();
//        if (entryAddressStr != null) {
//            Address entryAddress = GlobalState.flatAPI.toAddr(entryAddressStr);
//            return analyzeFromAddress(entryAddress);
//        } else {
//            GlobalState.eEntryFunction = null;//Utils.getEntryFunction();
//            if (GlobalState.eEntryFunction == null) {
//                Logging.error("Cannot find entry function, maybe unsupported file format or corrupted header.");
//                return false;
//            }
//            if (!analyzeFromMain()) {
//                Logging.info("Start from entrypoint");
//                Logging.info("Running solver on \"" + GlobalState.eEntryFunction + "()\" function");
//                InterSolver solver = new InterSolver(GlobalState.eEntryFunction, false);
//                solver.run();
//                return true;
//            }
//        }
//        return true;
        return true;
    }

    private void guiProcessResult() {
        if (!GlobalState.config.isGUI()) {
            return;
        }
        String msg = "Analysis finish!\n Found " + Logging.getCWEReports().size() + " CWE Warning.";
        GlobalState.ghidraScript.popup(msg);
        Logging.info(msg);
        for (CWEReport report : Logging.getCWEReports().keySet()) {
            GlobalState.ghidraScript.setBackgroundColor(report.getAddress(), Color.RED);
            GlobalState.ghidraScript.setEOLComment(report.getAddress(), report.toString());
            Logging.warn(report.toString());
        }
    }

    @Override
    public void run() throws Exception {
        GlobalState.config = new Config();
        // bvfinder mode
        boolean run_module = true;
        if (isRunningHeadless()) {
            String allArgString = StringUtils.join(getScriptArgs()).strip();
            GlobalState.config = HeadlessParser.parseConfig(allArgString);
        } else if(!run_module){
            GlobalState.ghidraScript = this;
            GlobalState.config = new Config();
            GlobalState.config.setGUI(true);
            ConfigDialog dialog = new ConfigDialog(GlobalState.config);
            dialog.showDialog();
            if (!dialog.isSuccess()) {
                return;
            }
        } else {
            GlobalState.config.setK(6);
            GlobalState.config.setCallStringK(6);
            GlobalState.config.setZ3TimeOut(1000);
            GlobalState.config.setTimeout(-1);
            GlobalState.config.setEnableZ3(false);
            GlobalState.config.setDebug(false);
            String[] checkers = {"BVFinder"};
            Arrays.stream(checkers)
                    .filter(CheckerManager::hasChecker)
                    .forEach(GlobalState.config::addChecker);
        }
        if (!Logging.init()) {
            return;
        }

        FunctionModelManager.initAll();
        if (GlobalState.config.isEnableZ3() && !Utils.checkZ3Installation()) {
            return;
        }
        Logging.info("Preparing the program");
        if (!prepareProgram()) {
            Logging.error("Failed to prepare the program");
            return;
        }
        if (isRunningHeadless()) {
            if (!Utils.registerExternalFunctionsConfig(GlobalState.currentProgram, GlobalState.config)) {
                return;
            }
        } else {
            Utils.loadCustomExternalFunctionFromLabelHistory(GlobalState.currentProgram);
        }
        GlobalState.arch = new Architecture(GlobalState.currentProgram);
        boolean success = analyze();
        if (!success) {
            Logging.error("Failed to analyze the program: no entrypoint.");
            return;
        }
        Logging.info("Running checkers");
        CheckerManager.runCheckers(GlobalState.config);
        guiProcessResult();
        GlobalState.reset();
    }
}
